word2vec
========

Word2Vec in C++ 11

See main.cc for building instructions and usage.

Author: https://github.com/jdeng/word2vec
