word2vec
========


Multiple version of word2vec. https://code.google.com/p/word2vec/