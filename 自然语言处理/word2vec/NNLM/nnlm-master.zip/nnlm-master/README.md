# NNLM
Neural Network Language Model

### 请独立自主完成作业→_→，仅给出非增广形式的写法做参考